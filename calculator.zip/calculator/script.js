const display = document.getElementById('userInput');
const buttons = Array.from(document.getElementsByClassName('btn'));
const clearButton = document.getElementById('clear');
const equalsButton = document.getElementById('equals');
const deleteButton = document.getElementById('del');

let currentInput = '';
let operator = '';
let previousInput = '';

buttons.forEach(button => {
    button.addEventListener('click', () => {
        const value = button.getAttribute('value');
        const op = button.getAttribute('operator'); // Get operator attribute correctly

        if (value) {
            currentInput += value;
            display.textContent = currentInput;
        }
        
        if (op) {
            if (currentInput === '' && op !== '-') {
                return; // Prevent operator at the start
            }
            operator = op;
            previousInput = currentInput;
            currentInput = '';
        }
    });
});

equalsButton.addEventListener('click', () => {
    if (previousInput === '' || currentInput === '') return;
    
    let result;
    const prev = parseFloat(previousInput);
    const current = parseFloat(currentInput);
    
    switch (operator) {
        case '+':
            result = prev + current;
            break;
        case '-':
            result = prev - current;
            break;
        case '*':
            result = prev * current;
            break;
        case '/':
            if (current === 0) {
                display.textContent = 'Error';
                return;
            }
            result = prev / current;
            break;
        default:
            return;
    }
    
    display.textContent = result;
    currentInput = result.toString(); // Convert result to string
    previousInput = '';
    operator = '';
});

clearButton.addEventListener('click', () => {
    currentInput = '';
    previousInput = '';
    operator = ''; // Corrected variable name
    display.textContent = '0';
});

deleteButton.addEventListener('click', () => {
  currentInput = currentInput.slice(0, -1);
  display.textContent = currentInput || '0'; // Display 0 if input is empty
});

/*const display = document.getElementById('userInput');
const buttons = Array.from(document.getElementsByClassName('btn'));
const clearButton = document.getElementById('clear');
const equalsButton = document.getElementById('equals');

let currentInput = '';
let operator = '';
let previousInput = '';

buttons.forEach(button => {
    button.addEventListener('click', () => {
        const value = button.getAttribute('value');
        const op = button.getAttribute('');
        
        if (value) {
            currentInput += value;
            display.textContent = currentInput;
        }
        
        if (op) {
            if (currentInput === '' && op !== '-') {
                return; // Prevent operator at the start
            }
            operator = op;
            previousInput = currentInput;
            currentInput = '';
        }
    });
});

equalsButton.addEventListener('click', () => {
    if (previousInput === '' || currentInput === '') return;
    
    let result;
    const prev = parseFloat(previousInput);
    const current = parseFloat(currentInput);
    
    switch (operator) {
        case '+':
            result = prev + current;
            break;
        case '-':
            result = prev - current;
            break;
        case '*':
            result = prev * current;
            break;
        case '/':
            if (current === 0) {
                display.textContent = 'Error';
                return;
            }
            result = prev / current;
            break;
        default:
            return;
    }
    
    display.textContent = result;
    currentInput = result;
    previousInput = '';
    operator = '';
});

clearButton.addEventListener('click', () => {
    currentInput = '';
    previousInput = '';
    opr = '';
    display.textContent = '0';
});*/
